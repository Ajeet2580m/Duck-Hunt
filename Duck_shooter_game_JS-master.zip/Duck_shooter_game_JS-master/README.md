## Duck hunt game 2.0
First project created with JavaScript. Inspired by popular 'Duck Hunt' game
developed and published by Nintendo in 1984.

### How to play:
The game has three modes:
1. Classic - two ducks, three shots - just like in the original game version
2. Modern - three ducks, five shots - this game mode contains new HQ graphics
3. EXTREME - after each round one more duck is added (up to 20), You have 50 shots to take them down. This mode provides full auto shooting.

The player receives points upon shooting each duck. High scores are stored in browser Local Storage.
To pass each round You must take down more than 80% of ducks. 

![dh3](https://user-images.githubusercontent.com/34944174/51281258-2aa0df00-19e2-11e9-95f7-2557d40a81ee.png)

![dh2](https://user-images.githubusercontent.com/34944174/51281239-1e1c8680-19e2-11e9-972d-ff1c8080af12.png)

![dh5](https://user-images.githubusercontent.com/34944174/51281214-0e04a700-19e2-11e9-9ed6-ff4e03880392.png)
